README — B-999-001 LC-MS Metabolomics Report Package
============================================================

本說明檔描述報告封存包內每個檔案的用途。
This README describes the purpose of every file in this report package.

────────────────────────────────────────────────────────────
【如何查看分析報告 / How to Open Reports】
────────────────────────────────────────────────────────────
各分析報告位於對應的 analysis_N/ 子資料夾中。
請先將此 zip 解壓縮，再進入對應資料夾，以瀏覽器開啟 report.html。

Each analysis report is in its own analysis_N/ subfolder.
Unzip this package first, then navigate into the subfolder
and open report.html in any web browser.

────────────────────────────────────────────────────────────
【分析資料夾 / Analysis Subfolders】
────────────────────────────────────────────────────────────

  analysis_1/ (Control vs. HFD)
    report.html              — 互動式雙語 HTML 分析報告（主要查看檔案）
                               Interactive bilingual HTML report (main file to open)
    significant_metabolites.csv — 顯著代謝物清單（依階層顯著性篩選）
                               Significant metabolites selected by tiered criteria
    tier_result.txt          — 顯著性篩選結果摘要（使用的階層與化合物數）
                               Tiered significance summary (tier used, compound count)
    figures/                 — 各圖表 300 DPI PNG + PDF 高解析度輸出
                               High-resolution figures (300 DPI PNG + PDF)
    pathway/pathway_results.csv — 僅含標題列：本分析未富集到代謝途徑
                               Header row only: no pathway reached enrichment
                               （非執行錯誤，詳見報告 Section 6.6）

────────────────────────────────────────────────────────────
【根目錄檔案 / Root-Level Files】
────────────────────────────────────────────────────────────

  results_targeted_metaboanalyst_analysis_N.csv
    正規化後的複合物豐度矩陣，可直接匯入 MetaboAnalyst 進行進一步統計分析。
    Normalized compound abundance matrix, ready for import into MetaboAnalyst.
    第 1 列為樣本群組標籤（Label），其後每列為一個化合物。
    Row 1 = sample group labels; subsequent rows = compounds.

    results_targeted_metaboanalyst_analysis_1.csv  (Control vs. HFD)

  B-999-001_peak_table.csv
    原始 MZmine 4 峰值表（已標注標準品比對結果），未正規化。
    Raw MZmine 4 peak table (with stdlib annotation), not normalized.
    詳見同名 _README.txt 說明欄位定義。
    See accompanying *_README.txt for column definitions.

  B-999-001_MappingTable.csv
    樣本對應表：樣本 ID、分析群組分配、技術複製對應關係。
    Sample mapping table: sample IDs, analysis group assignments.

────────────────────────────────────────────────────────────
【資料前處理說明 / Data Preprocessing】
────────────────────────────────────────────────────────────

  交付的 MetaboAnalyst CSV 已完成下列三個步驟（樣品類型：tissue）：
  The delivered MetaboAnalyst CSVs have already gone through all three steps:

  1. 秤重正規化（Weight normalization）：每個樣本的訊號除以其組織重量（mg）
     Weight normalization: each sample divided by its tissue weight (mg)
  2. 缺失值填補（half-minimum / ReplaceMin）：未偵測到的值以該化合物最小正值的一半取代
     Missing values imputed per feature as half the smallest positive value
  3. Log₂ 轉換：填補後取 log₂
     Log₂ transformation applied after imputation

  因此 CSV 內的數值皆為 log₂ 尺度（負值為正常現象，非錯誤）。
  Values are therefore on a log₂ scale; negative numbers are expected, not errors.

────────────────────────────────────────────────────────────
【MetaboAnalyst 線上分析 / Uploading to MetaboAnalyst】
────────────────────────────────────────────────────────────

  上傳網址 / Upload at:  https://www.metaboanalyst.ca
  選擇 Statistical Analysis [one factor] → 上傳 results_targeted_metaboanalyst_analysis_N.csv
  格式：Samples in columns (unpaired) / Comma separated (.csv)

  ⚠ 重要：資料已正規化完成，上傳後請將下列選項全部設為 None，
     否則會二次正規化，導致統計結果錯誤。
  ⚠ IMPORTANT: the data is already normalized — set ALL of the following to None,
     otherwise the data gets normalized twice and the statistics will be wrong.

     • Missing value estimation      → None (Leave as is)
     • Sample normalization          → None
     • Data transformation           → None
     • Data scaling                  → None（或依需求選 Auto scaling）
                                        (or Auto scaling if desired)

────────────────────────────────────────────────────────────
【化合物鑑定信心 / Identity confidence】
────────────────────────────────────────────────────────────
  本次使用的標準品庫沒有對應的 QC 標準品，未進行鑑定信心評估（not_assessed）。
  No QC standard list exists for this library; identity was not assessed.

────────────────────────────────────────────────────────────
【分析群組說明 / Analysis Findings】
────────────────────────────────────────────────────────────

【Analysis_1】Control vs. HFD
  樣品數：Control 3 / HFD 3｜物種：Mouse｜樣品類型：tissue｜鑑定化合物：26
  ⚠ 分組與樣品來源完全重合（Control = Sham、HFD = HFD）；兩者在統計上無法分離，本比較的差異可能來自來源本身而非分組條件，組內重複不等於獨立來源的重複。
    Group is confounded with sample source (Control = Sham, HFD = HFD); the two cannot be separated statistically, and replicates within a group are not independent sources.
  Q² = 0.671
  Tier 2 (raw p < 0.05)
  顯著代謝物：8
  FC 方向：↑ / ↓ 為 HFD 相較 Control 的變化（FC > 1 表示 HFD 較高）
    - Carnitine  ↑ HFD（FC 2.82）
    - Creatine  ↑ HFD（FC 1.94）
    - Creatinine  ↓ HFD（FC 0.54）
    - Glycerophosphocholine  ↓ HFD（FC 0.28）
    - Histidine  ↑ HFD（FC 3.47）
    - L-Acetylcarnitine  ↑ HFD（FC 6.20）
    - L-a-aminobutyric acid | 3-Aminoisobutanoate  ↑ HFD（FC 1.47）
    - Pipecolic acid  ↑ HFD（FC 3.39）

────────────────────────────────────────────────────────────
【注意事項 / Notes】
────────────────────────────────────────────────────────────

• report.html 須解壓縮後，在 analysis_N/ 資料夾內以瀏覽器開啟，
  直接從 zip 內開啟將導致圖表無法顯示。
  report.html must be opened from the extracted folder, not from inside the zip.
  Opening directly from zip will cause charts to fail.

• 互動式 3D 圖表（PCA / PLS-DA）需要現代瀏覽器（Chrome / Firefox / Edge）。
  Interactive 3D plots require a modern browser (Chrome / Firefox / Edge).

• 分析流程版本資訊詳見各報告 Section 6（材料與方法）。
  Pipeline version and method details are in Section 6 of each report.

• Section 6 的樣品前處理段落為通用範本，並非本次實驗的實際紀錄；
  引用於論文前，請依實際的樣品類型、取樣與萃取流程核對後改寫。
  The sample-preparation text in Section 6 is a generic template, not a record
  of this run — verify it against how these samples were actually prepared
  before citing it in a manuscript.
