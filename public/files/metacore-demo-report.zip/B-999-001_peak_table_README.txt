Annotated Peak Table — Stdlib-Matched Features Only
====================================================
This file contains raw LC-MS feature intensities for features that were
successfully matched against the standard library (stdlib).
No normalization has been applied; values are raw MZmine 4 peak heights.

Columns
-------
  compound_name : Matched compound name(s); multiple candidates separated by " | "
  PubChemCID    : PubChem Compound ID(s) of matched compound(s)
  formula       : Molecular formula
  mode          : Ionization mode (pos = positive, neg = negative)
  row_id        : Internal MZmine feature ID
  row_mz        : Observed mass-to-charge ratio (m/z)
  ppm_error     : m/z deviation from theoretical value (parts per million)
  <sample>...   : Peak height (ion intensity) for each sample; 0 = not detected

Notes
-----
- Row retention time is not included in this file.
- Only features matched to the standard library are included; unmatched
  features are excluded.
- For normalized data suitable for statistical analysis, see
  results_targeted_metaboanalyst_*.csv.
